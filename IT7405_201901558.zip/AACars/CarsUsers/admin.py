from django.contrib import admin
from .models import NormalUser

# Register your models here.
admin.site.register(NormalUser)