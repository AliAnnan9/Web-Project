from django.apps import AppConfig


class CarsusersConfig(AppConfig):
    name = 'CarsUsers'
