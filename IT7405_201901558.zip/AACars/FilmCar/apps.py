from django.apps import AppConfig


class FilmcarConfig(AppConfig):
    name = 'FilmCar'
