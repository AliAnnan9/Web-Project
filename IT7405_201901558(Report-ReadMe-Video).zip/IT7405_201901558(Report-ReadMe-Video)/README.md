*Project Name AACars
This is a webpage developed by MongoDB with Django to connect them both and it is all about a car dealership for JDM which is about Japan's late 90's cars that not everyone values them and knows there worth ensuring easy navigation between the pages

*the web mainly contains important functionality :
  - List the Cars
  - Buy a car
  - book an appointment to film with the car
  - login/logout
  - register
    
*Pip List
  asgiref    3.2.10
  Django     3.1
  djongo     1.3.6
  dnspython  2.4.2
  Pillow     10.1.0
  pip        23.3.1
  pymongo    3.12.1
  pytz       2022.6
  setuptools 68.0.0
  sqlparse   0.2.4
  tzdata     2023.3
  wheel      0.41.2

*Setup Our page 
  First we need to lunch anaconda promt navigate to the project file activate the vertual envirment "ProjectEnv" and then use "python manage.py runserver"

*Admin Account
Username: Annan
Password: admin
